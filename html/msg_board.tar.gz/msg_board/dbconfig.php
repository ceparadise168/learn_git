<?php
$host = "localhost";
$user = "root";
$password = "Eric_tu168";
$datbase = "msgboard";
mysql_connect($host,$user,$password);
mysql_select_db($datbase);
?>
